<?php defined('BASEPATH') OR exit('No direct script access allowed');

	class Transaction extends MY_Controller {

		public function __construct(){
			parent::__construct();
			$this->load->model('admin/admin_model', 'admin');
			$this->load->library('datatable'); // loaded my custom serverside datatable library

			$this->rbac->check_module_access();
		}

		public function index(){
			$data['get_user_detail'] = $this->admin->get_user_detail();
			$data['view'] = 'admin/transaction/index';
			$this->load->view('layout', $data);
		}

	}

?>	