<?php defined('BASEPATH') OR exit('No direct script access allowed');

	class History extends MY_Controller {

		public function __construct(){
			parent::__construct();
			$this->load->library('datatable'); // loaded my custom serverside datatable library

			$this->rbac->check_module_access();
		}

		// Server side database join example
		public function index(){
			$data['view'] = 'admin/history/index';
			$this->load->view('layout', $data);
		}

	}

?>	