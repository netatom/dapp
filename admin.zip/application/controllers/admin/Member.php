<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Member extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->library('rbac');
		$this->load->model('admin/admin_model', 'admin');

		// $this->rbac->check_module_access();
    }

	//-----------------------------------------------------		
	function index($type='')
	{
		$this->session->set_userdata('filter_type',$type);
		$this->session->set_userdata('filter_keyword','');
		$this->session->set_userdata('filter_status',1);
		
		$data['admin_roles'] = $this->admin->get_admin_roles();
		$data['view']='admin/member/index';
		$this->load->view('layout',$data);
	}

	//---------------------------------------------------------
	function filterdata()
	{
		$this->session->set_userdata('filter_type',$this->input->post('type'));
		$this->session->set_userdata('filter_status',$this->input->post('status'));
		$this->session->set_userdata('filter_keyword',$this->input->post('keyword'));
	}

	//--------------------------------------------------		
	function list_data()
	{
		$data['info'] = $this->admin->get_all_verified();
		$this->load->view('admin/member/list',$data);
	}
	
}

?>