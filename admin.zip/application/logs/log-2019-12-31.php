<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-31 05:56:05 --> 404 Page Not Found: Theme/common
ERROR - 2019-12-31 05:56:15 --> 404 Page Not Found: Theme/common
ERROR - 2019-12-31 06:01:21 --> 404 Page Not Found: Theme/common
ERROR - 2019-12-31 06:01:48 --> 404 Page Not Found: Theme/common
ERROR - 2019-12-31 06:13:44 --> 404 Page Not Found: Theme/common
ERROR - 2019-12-31 06:14:15 --> 404 Page Not Found: Theme/common
ERROR - 2019-12-31 06:14:23 --> 404 Page Not Found: Theme/common
ERROR - 2019-12-31 06:14:28 --> Severity: error --> Exception: Unable to locate the model you have specified: Inventory_model C:\xampp\htdocs\admin\system\core\Loader.php 344
ERROR - 2019-12-31 06:14:36 --> Severity: error --> Exception: Unable to locate the model you have specified: Inventory_model C:\xampp\htdocs\admin\system\core\Loader.php 344
ERROR - 2019-12-31 06:14:46 --> 404 Page Not Found: Theme/common
ERROR - 2019-12-31 06:14:56 --> 404 Page Not Found: Theme/common
ERROR - 2019-12-31 06:15:46 --> 404 Page Not Found: Theme/common
ERROR - 2019-12-31 06:15:56 --> 404 Page Not Found: Theme/common
ERROR - 2019-12-31 06:16:05 --> 404 Page Not Found: Theme/common
ERROR - 2019-12-31 07:03:54 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2019-12-31 07:03:54 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2019-12-31 07:03:59 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2019-12-31 07:03:59 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2019-12-31 07:04:02 --> 404 Page Not Found: Theme/common
ERROR - 2019-12-31 07:04:08 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2019-12-31 07:04:08 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2019-12-31 07:04:14 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2019-12-31 07:04:14 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2019-12-31 07:04:16 --> 404 Page Not Found: Theme/common
ERROR - 2019-12-31 07:04:54 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2019-12-31 07:04:54 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2019-12-31 07:04:56 --> 404 Page Not Found: Theme/common
ERROR - 2019-12-31 07:05:01 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2019-12-31 07:05:01 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2019-12-31 07:05:03 --> 404 Page Not Found: Theme/common
