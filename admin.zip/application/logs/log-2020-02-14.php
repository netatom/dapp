<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-14 03:20:10 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:20:10 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:21:22 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:21:22 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:21:24 --> 404 Page Not Found: Theme/common
ERROR - 2020-02-14 03:21:37 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:21:37 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:21:39 --> 404 Page Not Found: Theme/common
ERROR - 2020-02-14 03:21:41 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:21:41 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:21:45 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:21:45 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:21:47 --> 404 Page Not Found: Theme/common
ERROR - 2020-02-14 03:22:21 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:22:21 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:22:24 --> 404 Page Not Found: Theme/common
ERROR - 2020-02-14 03:22:26 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:22:26 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:22:29 --> 404 Page Not Found: Theme/common
ERROR - 2020-02-14 03:22:38 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:22:38 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:22:40 --> 404 Page Not Found: Theme/common
ERROR - 2020-02-14 03:25:25 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:25:25 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:25:29 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:25:29 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:25:36 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:25:36 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:26:10 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:26:10 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:26:13 --> 404 Page Not Found: Theme/common
ERROR - 2020-02-14 03:26:32 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:26:33 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:26:39 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:26:39 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:26:43 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:26:43 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:26:48 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:26:48 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:26:51 --> 404 Page Not Found: Theme/common
ERROR - 2020-02-14 03:26:53 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:26:53 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:26:58 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:26:58 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:34:38 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:34:38 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:34:40 --> 404 Page Not Found: Theme/common
ERROR - 2020-02-14 03:34:44 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:34:44 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:34:57 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:34:57 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:35:14 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:35:14 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:35:16 --> 404 Page Not Found: Theme/common
ERROR - 2020-02-14 03:35:31 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:35:31 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:35:36 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:35:36 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:35:39 --> 404 Page Not Found: Theme/common
ERROR - 2020-02-14 03:35:41 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:35:41 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:35:43 --> 404 Page Not Found: Theme/common
ERROR - 2020-02-14 03:35:45 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:35:45 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:35:48 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:35:48 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:38:02 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:38:02 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:38:05 --> 404 Page Not Found: Theme/common
ERROR - 2020-02-14 03:38:07 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:38:07 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:39:42 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:39:42 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:39:45 --> 404 Page Not Found: Theme/common
ERROR - 2020-02-14 03:40:09 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:40:09 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:40:16 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:40:16 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:40:18 --> 404 Page Not Found: Theme/common
ERROR - 2020-02-14 03:40:29 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:40:29 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:40:33 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:40:33 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:40:36 --> 404 Page Not Found: Theme/common
ERROR - 2020-02-14 03:40:37 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:40:37 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:40:40 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:40:40 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:40:46 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:40:46 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:45:06 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:45:06 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:45:10 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:45:10 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:45:20 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:45:20 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:45:24 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:45:24 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:45:32 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:45:32 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:45:35 --> 404 Page Not Found: Theme/common
ERROR - 2020-02-14 03:45:38 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:45:38 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:46:17 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:46:17 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:46:24 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:46:24 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:46:26 --> 404 Page Not Found: Theme/common
ERROR - 2020-02-14 03:46:29 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:46:29 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:46:35 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:46:35 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 03:46:37 --> 404 Page Not Found: Theme/common
ERROR - 2020-02-14 05:21:37 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:21:37 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:21:39 --> 404 Page Not Found: Theme/common
ERROR - 2020-02-14 05:21:44 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:21:44 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:21:46 --> 404 Page Not Found: Theme/common
ERROR - 2020-02-14 05:23:25 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:23:25 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:25:24 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:25:24 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:25:29 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:25:29 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:25:34 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:25:34 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:25:37 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:25:37 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:25:41 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:25:41 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:25:43 --> 404 Page Not Found: Theme/common
ERROR - 2020-02-14 05:25:47 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:25:47 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:50:34 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:50:34 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:50:39 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:50:39 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:50:41 --> 404 Page Not Found: Theme/common
ERROR - 2020-02-14 05:50:43 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:50:43 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:51:02 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:51:02 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:51:06 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:51:06 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:52:05 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:52:05 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:52:23 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:52:23 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:52:25 --> 404 Page Not Found: Theme/common
ERROR - 2020-02-14 05:52:31 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:52:31 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:52:33 --> 404 Page Not Found: Theme/common
ERROR - 2020-02-14 05:52:43 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:52:43 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-02-14 05:52:46 --> 404 Page Not Found: Theme/common
