<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-22 02:28:44 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:28:44 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:28:50 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:28:50 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:28:52 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 02:28:55 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:28:55 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:29:03 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:29:03 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:29:05 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 02:29:08 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:29:08 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:29:12 --> Severity: error --> Exception: Unable to locate the model you have specified: Inventory_model C:\xampp\htdocs\admin\system\core\Loader.php 344
ERROR - 2020-01-22 02:29:13 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:29:13 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:29:17 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:29:17 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:33:31 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:33:31 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:33:32 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 02:33:41 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:33:41 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:33:46 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:33:46 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:33:47 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 02:33:49 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:33:49 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:33:57 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:33:57 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:35:33 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:35:33 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:36:39 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:36:39 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:36:40 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 02:36:50 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:36:50 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:37:08 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:37:08 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:37:13 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:37:13 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:37:14 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 02:37:28 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:37:28 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:37:36 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:37:36 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:38:04 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:38:04 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:38:10 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:38:10 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:47:44 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:47:44 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:47:51 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:47:51 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:48:13 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:48:13 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:48:17 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:48:17 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:48:18 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 02:48:20 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:48:20 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:48:21 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 02:48:24 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:48:24 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:48:34 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:48:34 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:51:17 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:51:17 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:51:37 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:51:37 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:51:38 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 02:51:41 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:51:41 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:51:49 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:51:49 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:51:50 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 02:51:56 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:51:56 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:52:01 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:52:01 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:52:12 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:52:12 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:52:13 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 02:52:16 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:52:16 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:52:21 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:52:21 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:52:26 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:52:26 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:52:27 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 02:52:30 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:52:30 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:52:34 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:52:34 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:52:35 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 02:52:37 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:52:37 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:53:13 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:53:14 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:53:17 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:53:17 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:53:18 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 02:53:33 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:53:33 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:53:34 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 02:53:37 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:53:37 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:53:39 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:53:39 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:53:40 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 02:53:44 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:53:44 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:53:47 --> Severity: error --> Exception: Unable to locate the model you have specified: Inventory_model C:\xampp\htdocs\admin\system\core\Loader.php 344
ERROR - 2020-01-22 02:53:48 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:53:48 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:53:51 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:53:51 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 02:53:52 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 03:30:11 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:30:11 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:36:10 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:36:10 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:36:11 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 03:36:59 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:36:59 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:37:08 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:37:08 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:37:11 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:37:11 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:37:15 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:37:15 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:37:34 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:37:34 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:38:04 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:38:04 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:38:13 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:38:13 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:38:18 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:38:18 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:38:20 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:38:20 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:38:24 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:38:24 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:38:28 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:38:28 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:38:39 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:38:39 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:39:03 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:39:03 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:39:10 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:39:10 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:39:12 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:39:12 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:39:14 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:39:14 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:39:17 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:39:17 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:39:26 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:39:26 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:39:29 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:39:29 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:39:40 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:39:40 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:39:41 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 03:39:46 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:39:46 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:39:50 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:39:50 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:39:51 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 03:39:55 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:39:55 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:40:04 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:40:04 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:40:05 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 03:40:44 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:40:44 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:41:03 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:41:03 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:41:09 --> Severity: error --> Exception: Unable to locate the model you have specified: Inventory_model C:\xampp\htdocs\admin\system\core\Loader.php 344
ERROR - 2020-01-22 03:41:10 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:41:10 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:41:12 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:41:12 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:41:15 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:41:15 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:41:17 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 03:41:20 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:41:20 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:41:23 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:41:23 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:41:24 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 03:41:30 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:41:30 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:41:32 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:41:32 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:41:33 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 03:45:57 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:45:57 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:45:58 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 03:46:03 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:46:03 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:46:08 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:46:08 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:46:23 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:46:23 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:46:24 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 03:46:29 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:46:29 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:46:31 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 03:46:34 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:46:34 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:46:45 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:46:45 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:46:49 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:46:49 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:46:50 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 03:50:57 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:50:57 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:51:07 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:51:07 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 03:51:07 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 05:47:37 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 05:47:37 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 05:47:37 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 05:48:04 --> Severity: Warning --> include(include/sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 54
ERROR - 2020-01-22 05:48:04 --> Severity: Warning --> include(): Failed opening 'include/sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 54
ERROR - 2020-01-22 05:48:04 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 05:48:04 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 05:48:05 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 05:48:23 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 05:48:23 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 05:48:25 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 05:48:25 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 05:48:26 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 05:48:30 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 05:48:30 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 05:48:30 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 05:48:31 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 05:48:31 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 05:48:33 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 05:48:33 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 05:48:33 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 05:48:34 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 05:48:34 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 05:48:36 --> Severity: error --> Exception: Unable to locate the model you have specified: Inventory_model C:\xampp\htdocs\admin\system\core\Loader.php 344
ERROR - 2020-01-22 05:48:37 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 05:48:37 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 05:48:38 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 05:48:38 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 05:48:39 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 05:49:27 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 05:49:27 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 05:49:30 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 05:49:30 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 05:49:31 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 05:49:42 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 05:49:42 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 05:49:42 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:02:17 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:02:17 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:02:17 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:02:23 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:02:23 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:02:25 --> Severity: error --> Exception: Unable to locate the model you have specified: Inventory_model C:\xampp\htdocs\admin\system\core\Loader.php 344
ERROR - 2020-01-22 06:02:26 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:02:26 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:02:27 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:02:27 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:02:28 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:03:49 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:03:49 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:03:50 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:03:50 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:04:39 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:04:39 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:04:42 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:04:42 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:04:48 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:04:48 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:04:49 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:04:49 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:04:51 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:04:51 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:04:53 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:04:53 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:04:54 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:04:54 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:05:14 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:05:14 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:08:59 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:08:59 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:09:01 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:09:01 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:09:09 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:09:09 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:09:09 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:14:02 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:14:02 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:14:09 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:14:09 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:14:10 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:14:18 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:14:18 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:14:23 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:14:23 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:14:23 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:22:11 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:22:11 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:22:11 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:23:54 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:23:54 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:29:46 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:29:46 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:30:38 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:30:38 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:31:12 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:31:12 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:32:57 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:32:57 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:34:21 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:34:21 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:34:24 --> Severity: error --> Exception: Unable to locate the model you have specified: Inventory_model C:\xampp\htdocs\admin\system\core\Loader.php 344
ERROR - 2020-01-22 06:34:26 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:34:26 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:34:27 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:34:27 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:34:30 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:34:30 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:34:30 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:34:33 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:34:33 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:34:34 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:34:34 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:34:34 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:35:42 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:35:42 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:35:43 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:35:44 --> Severity: error --> Exception: Unable to locate the model you have specified: Inventory_model C:\xampp\htdocs\admin\system\core\Loader.php 344
ERROR - 2020-01-22 06:35:45 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:35:45 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:35:47 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:35:47 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:35:48 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:35:48 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:35:53 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:35:53 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:35:53 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:35:58 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:35:58 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:36:00 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:36:00 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:36:03 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:36:03 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:36:04 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:36:04 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:36:09 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:36:09 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:36:16 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:36:16 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:36:18 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:36:18 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:36:18 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:36:36 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:36:36 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:36:36 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:36:38 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:36:38 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:36:41 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:36:41 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:36:41 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:36:43 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:36:43 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:36:45 --> Severity: error --> Exception: Unable to locate the model you have specified: Inventory_model C:\xampp\htdocs\admin\system\core\Loader.php 344
ERROR - 2020-01-22 06:37:57 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:37:57 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:37:58 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:37:58 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:37:58 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:38:04 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:38:04 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:38:07 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:38:07 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:38:13 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:38:13 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:38:15 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:38:15 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:38:15 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:38:17 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:38:17 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:38:18 --> Severity: error --> Exception: Unable to locate the model you have specified: Inventory_model C:\xampp\htdocs\admin\system\core\Loader.php 344
ERROR - 2020-01-22 06:38:19 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:38:19 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:38:20 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:38:20 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:38:22 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:38:22 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:38:23 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:38:25 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:38:25 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:38:32 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:38:32 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:38:41 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:38:41 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:38:43 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:38:43 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:38:53 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:38:53 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:38:55 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:38:55 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:38:57 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:38:57 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:39:06 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:39:06 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:39:07 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:39:09 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:39:09 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:39:10 --> Severity: error --> Exception: Unable to locate the model you have specified: Inventory_model C:\xampp\htdocs\admin\system\core\Loader.php 344
ERROR - 2020-01-22 06:39:12 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:39:12 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:39:41 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:39:41 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:39:42 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:39:45 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:39:45 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:40:03 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:40:03 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:40:07 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:40:07 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:40:07 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:40:15 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:40:15 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:40:16 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:40:16 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:40:17 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:40:19 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:40:19 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:40:22 --> Severity: error --> Exception: Unable to locate the model you have specified: Inventory_model C:\xampp\htdocs\admin\system\core\Loader.php 344
ERROR - 2020-01-22 06:40:31 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:40:31 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:40:31 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:40:32 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:40:32 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:40:33 --> Severity: error --> Exception: Unable to locate the model you have specified: Inventory_model C:\xampp\htdocs\admin\system\core\Loader.php 344
ERROR - 2020-01-22 06:40:34 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:40:34 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:40:36 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:40:36 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:40:37 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:40:37 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:40:38 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:41:46 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:41:46 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:42:00 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:42:00 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:42:00 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:42:05 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:42:05 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:42:07 --> Severity: error --> Exception: Unable to locate the model you have specified: Inventory_model C:\xampp\htdocs\admin\system\core\Loader.php 344
ERROR - 2020-01-22 06:42:08 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:42:08 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:42:36 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:42:36 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:42:39 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:42:39 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:42:40 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:42:42 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:42:42 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:42:44 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:42:44 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:42:45 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:44:47 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:44:47 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:44:47 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:44:58 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:44:58 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:44:58 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:45:00 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:45:00 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:45:02 --> Severity: error --> Exception: Unable to locate the model you have specified: Inventory_model C:\xampp\htdocs\admin\system\core\Loader.php 344
ERROR - 2020-01-22 06:45:03 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:45:03 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:45:05 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:45:05 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:45:06 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:45:06 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:45:06 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:45:11 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:45:11 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:45:12 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:45:12 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:45:13 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:45:52 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:45:52 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:46:23 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:46:23 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:46:25 --> Severity: error --> Exception: Unable to locate the model you have specified: Inventory_model C:\xampp\htdocs\admin\system\core\Loader.php 344
ERROR - 2020-01-22 06:46:26 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:46:26 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:46:31 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:46:31 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:46:32 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:46:32 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:46:33 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:46:33 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:46:34 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:46:34 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:46:34 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:46:35 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:46:35 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:46:36 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:46:37 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:46:37 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:46:37 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:46:41 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:46:41 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:46:42 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:46:42 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:46:44 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:46:44 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:46:45 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:47:06 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:47:06 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:47:07 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:50:12 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:50:12 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:50:12 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:50:26 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:50:26 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:50:29 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:50:29 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:50:31 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:50:31 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:50:44 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:50:44 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:50:46 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:50:46 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:50:55 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:50:55 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:50:56 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:50:56 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:50:58 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:50:58 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:52:46 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:52:46 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:52:48 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:52:48 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:52:49 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:52:51 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:52:51 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:52:58 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:52:58 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:52:59 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:52:59 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:53:01 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:53:01 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:53:01 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 06:53:14 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:53:14 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:54:20 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:54:20 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:54:26 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:54:26 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:54:28 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 06:54:28 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 08:02:32 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 08:02:32 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 08:02:33 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 08:02:35 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 08:02:35 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 08:02:37 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 08:02:37 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 08:02:37 --> 404 Page Not Found: Theme/common
ERROR - 2020-01-22 08:02:42 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 08:02:42 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 08:02:48 --> Severity: error --> Exception: Unable to locate the model you have specified: Inventory_model C:\xampp\htdocs\admin\system\core\Loader.php 344
ERROR - 2020-01-22 08:02:50 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-22 08:02:50 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
