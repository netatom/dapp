<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-15 07:45:10 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-04-15 07:45:10 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-04-15 07:45:13 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-04-15 07:45:13 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-04-15 07:45:16 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-04-15 07:45:16 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-04-15 07:45:17 --> 404 Page Not Found: Theme/common
ERROR - 2020-04-15 07:45:20 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-04-15 07:45:20 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-04-15 07:45:33 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-04-15 07:45:33 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-04-15 07:48:00 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-04-15 07:48:00 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-04-15 07:49:53 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-04-15 07:49:53 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-04-15 07:49:54 --> 404 Page Not Found: Theme/common
ERROR - 2020-04-15 07:50:41 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-04-15 07:50:41 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-04-15 07:50:41 --> 404 Page Not Found: Theme/common
ERROR - 2020-04-15 07:50:44 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-04-15 07:50:44 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-04-15 07:51:30 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-04-15 07:51:30 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
