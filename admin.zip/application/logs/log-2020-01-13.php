<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-01-13 03:33:06 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-13 03:33:06 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\admin\application\views\layout.php 76
ERROR - 2020-01-13 03:33:18 --> 404 Page Not Found: admin/Group/index
ERROR - 2020-01-13 03:33:32 --> 404 Page Not Found: admin/Admin/group
