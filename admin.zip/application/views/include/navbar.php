

  <header class="main-header">
    <!-- Logo -->
    <a href="<?= base_url('admin');?>" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>Eth</b>Bank</span>
      
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Eth</b> Bank</span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>

    <!-- Navbar Search -->      
      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="<?= base_url() ?>public/dist/img/user2-160x160.jpg" class="user-image" alt="User Image">
              <span class="hidden-xs"><?= ucwords($this->session->userdata('username')); ?></span>
            </a>

            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="<?= base_url() ?>public/dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
                <p>
                  Management Support Team
                </p>
              </li>
              <!-- Menu Body -->
              <li class="user-body">
                <div class="row">
                  <div class="col-xs-4 text-center">Balance(Eth):</div>
                  <div id="wallet_balance" class="col-xs-8 text-center"></div>
                </div>
                <!-- /.row -->
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-right">
                  <a href="<?= site_url('auth/logout'); ?>" class="btn btn-default btn-flat">Sign out</a>
                </div>
                <div class="pull-left">
                  <a href="<?= base_url('admin/profile'); ?>" class="btn btn-default btn-flat">profile</a>
                </div>
              </li>
            </ul>
          </li>
        </ul>
      </div>
    </nav>
  </header>
 
  <script>
// coinbase wallet
// const wal = web3.eth.accounts[0];
// console.log(wal);

// coinbase balance
const coi = parseFloat(web3.fromWei(web3.eth.getBalance(web3.eth.coinbase))); 
// console.log(coi);

// wallet by seqence
// const wal11 = parseFloat(web3.fromWei(web3.eth.getBalance(web3.eth.accounts[0]))); 
// const wal22 = parseFloat(web3.fromWei(web3.eth.getBalance(web3.eth.accounts[1]))); 
// const wal33 = parseFloat(web3.fromWei(web3.eth.getBalance(web3.eth.accounts[2]))); 
// console.log(wal11);
// console.log(wal22);
// console.log(wal33);

// wallet, balance by seqence
const accounts = web3.eth.accounts;
accounts.forEach(function(element) {

  // console.log(element);
  const my_wallet_address = '<?= ucwords($this->session->userdata('wallet_address')); ?>';
  // console.log(my_wallet_address);

  if(element == my_wallet_address){
    // console.log(element);
    // console.log(my_wallet_address);
    const my_wallet_balance = parseFloat(web3.fromWei(web3.eth.getBalance(element))); 
    // console.log(my_wallet_balance);
    $('#wallet_balance').html(my_wallet_balance);
  }

});

// total balance
const list = web3.eth.accounts;
let total = 0;
list.map(el => {
      const tempB = parseFloat(web3.fromWei(web3.eth.getBalance(el), 'ether'));
      total += tempB;
    });
// console.log(total);

$(document).ready(function() {
        // console.log('<?= ucwords($this->session->userdata('wallet_address')); ?>');
        //$('#wallet_address').html('<?= ucwords($this->session->userdata('wallet_address')); ?>'); // text값을 변환
        // console.log("start");
    });
</script>