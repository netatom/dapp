<?php 
$cur_tab = $this->uri->segment(2)==''?'dashboard': $this->uri->segment(2);  
?>  

  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li id="dashboard" class="treeview">
          <a href="<?= base_url('admin/dashboard'); ?>">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
        </li>
      </ul>

      <?php if($this->rbac->check_module_permission('admin')): ?>  
      <ul class="sidebar-menu">
        <li id="admin" class="treeview">
          <a href="<?= base_url('admin/admin'); ?>">
            <i class="fa fa-user"></i> <span>User Manage</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
        </li>
      </ul>
      <?php endif; ?>

      <?php if($this->rbac->check_module_permission('admin_roles')): ?>  
       <ul class="sidebar-menu">
        <li id="admin_roles" class="treeview">
          <a href="<?= base_url('admin/admin_roles'); ?>">
            <i class="fa fa-anchor"></i> <span>Roles & Permissions</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
        </li>
      </ul>
      <?php endif; ?>


      <?php if($this->rbac->check_module_permission('member')): ?>  
      <ul class="sidebar-menu">
        <li id="admin" class="treeview">
          <a href="<?= base_url('admin/member'); ?>">
            <i class="fa fa-users"></i> <span>Members</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
        </li>
      </ul>
      <?php endif; ?>

      <?php if($this->rbac->check_module_permission('transaction')): ?>
      <ul class="sidebar-menu">
        <li id="transaction" class="treeview">
            <a href="<?= base_url('admin/transaction'); ?>">
              <i class="fa fa-exchange"></i> <span>Transaction</span>
              <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
              </span>
            </a>
          </li>
      </ul>
      <?php endif; ?>

      <?php if($this->rbac->check_module_permission('history')): ?>
      <ul class="sidebar-menu">
        <li id="history" class="treeview">
            <a href="<?= base_url('admin/history'); ?>">
              <i class="fa fa-file-text"></i> <span>History</span>
              <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
              </span>
            </a>
          </li>
      </ul>
      <?php endif; ?>

    </section>
    <!-- /.sidebar -->
  </aside>

  
<script>
  $("#<?= $cur_tab ?>").addClass('active');
</script>
