<?php
if(isset($_GET['id'])) {
  $id = $_GET['id'];
  //echo $id;
} else {
  $id ="";
}

if(isset($_GET['partner_id'])) {
  $partner_id = $_GET['partner_id'];
  //echo $partner_id;
} else {
  $partner_id ="";
}

if(isset($_GET['amount'])) {
  $amount = $_GET['amount'];
  //echo $amount;
} else {
  $amount ="";
}
?>
 <section class="content">
   <div class="box">
    <div class="box-header">
      <h3 class="box-title">History</h3>
    </div>
    <!-- /.box-header -->
    <div class="box-body table-responsive">
      <table class="table table-bordered" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th width="30%">My Account</th>
                    <th width="30%">Remittance Account</th>
                    <th width="30%">Banance(Ether)</th>
                    <th width="10%">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <input type="hidden" id="next_no" value="">
                    <td><input class="form-control" id="account" value="<?php echo $id;?>" readonly="true"></td>
                    <td><input class="form-control" id="receiver" value="<?php echo $partner_id;?>" readonly="true"></td>
                    <td><input class="form-control" id="amount" value="<?php echo $amount;?>" readonly="true"></td>
                    <td>
                        <?php if (!empty($amount)) {
                          //echo '<a class="btn btn-primary btn-block" id="write_btn">Write</a>';
                        } 
                        ?>
                        <a class="btn btn-primary btn-block" id="write_btn">Write</a>
                    </td>
                  </tr>
                </tbody>
            </table>

            <table class="table table-bordered" id="logtable" width="100%" cellspacing="0">
                  <tr>
                    <th width="10%">NO</th>
                    <th width="30%">My Account</th>
                    <th width="30%">Remittance Account</th>
                    <th width="10%">Banance(Eth)</th>
                    <th width="20%">Date</th>
                  </tr>
            </table>
    </div>
    <!-- /.box-body -->
  </div>
  <!-- /.box -->
</section>  

  <!-- smart contract-->
  <!-- It doesn't include abi js file -->
  <!-- <script type="text/javascript" src="<?= base_url() ?>public/js/abi.js"></script> -->
  <script>

  const abi = [
    {
      "constant": false,
      "inputs": [
        {
          "name": "_initNumber",
          "type": "uint256"
        },
        {
          "name": "_firstString",
          "type": "string"
        },
        {
          "name": "_secondString",
          "type": "string"
        },
        {
          "name": "_thirdString",
          "type": "string"
        }
      ],
      "name": "addProStru",
      "outputs": [],
      "payable": false,
      "stateMutability": "nonpayable",
      "type": "function"
    },
    {
      "anonymous": false,
      "inputs": [
        {
          "indexed": false,
          "name": "number",
          "type": "uint256"
        },
        {
          "indexed": false,
          "name": "productName",
          "type": "string"
        },
        {
          "indexed": false,
          "name": "productName2",
          "type": "string"
        },
        {
          "indexed": false,
          "name": "location",
          "type": "string"
        },
        {
          "indexed": false,
          "name": "timestamp",
          "type": "uint256"
        }
      ],
      "name": "product",
      "type": "event"
    },
    {
      "constant": true,
      "inputs": [],
      "name": "getNumOfProducts",
      "outputs": [
        {
          "name": "",
          "type": "uint8"
        }
      ],
      "payable": false,
      "stateMutability": "view",
      "type": "function"
    },
    {
      "constant": true,
      "inputs": [
        {
          "name": "_index",
          "type": "uint256"
        }
      ],
      "name": "getProductStruct",
      "outputs": [
        {
          "name": "",
          "type": "uint256"
        },
        {
          "name": "",
          "type": "string"
        },
        {
          "name": "",
          "type": "string"
        },
        {
          "name": "",
          "type": "string"
        },
        {
          "name": "",
          "type": "uint256"
        }
      ],
      "payable": false,
      "stateMutability": "view",
      "type": "function"
    },
    {
      "constant": true,
      "inputs": [
        {
          "name": "",
          "type": "uint256"
        }
      ],
      "name": "productes",
      "outputs": [
        {
          "name": "number",
          "type": "uint256"
        },
        {
          "name": "productName",
          "type": "string"
        },
        {
          "name": "productName2",
          "type": "string"
        },
        {
          "name": "locaton",
          "type": "string"
        },
        {
          "name": "timestamp",
          "type": "uint256"
        }
      ],
      "payable": false,
      "stateMutability": "view",
      "type": "function"
    }
  ];

    const contractAddress = '0x584BC51E2C25331EE5908915a0DcB8A66e5a3A1F';
    // remix 에서 Deployed Contracts address
    // remix 에서는 depoly되면 아래에 contractAddress가 생김
    const smartContract = web3.eth.contract(abi).at(contractAddress);
  </script>
<script>
    $(document).ready(function(){
      
			$("#write_btn").click(function(){
              const pronumber = document.getElementById('next_no').value;
              const proname = document.getElementById('account').value; // my account 
              const proname2 = document.getElementById('receiver').value; // my remittance Account
              const proloc = document.getElementById('amount').value; // amount
              const account = document.getElementById('account').value; // 인증을 위한 account

                smartContract.addProStru(
                  pronumber,
                  proname,
                  proname2,
                  proloc,
                  { from: account, gas: 2000000 },
                  (err, result) => {
                    if (!err) alert('트랜잭션이 성공적으로 전송되었습니다.\n' + result);
                  }
                );

            });

            
    });

    function showList() {
      const table = document.getElementById('logtable');
      const length = smartContract.getNumOfProducts();
      smartContract.product().watch((err, res) => {
        if (!err) {
          console.dir(res);
          const row = table.insertRow();
          const cell1 = row.insertCell(0);
          const cell2 = row.insertCell(1);
          const cell3 = row.insertCell(2);
          const cell4 = row.insertCell(3);
          const cell5 = row.insertCell(4);
          cell1.innerHTML = res.args.number.c[0];
          cell2.innerHTML = res.args.productName;
          cell3.innerHTML = res.args.productName2;
          cell4.innerHTML = res.args.location;
          cell5.style.width = '60%';
          cell5.innerHTML = new Date(res.args.timestamp.c[0]);
        }
      });
      for (let i = 0; i < length; i++) {
        const product = smartContract.getProductStruct(i);
        const toString = product.toString();
        const strArray = toString.split(',');
        const timestamp = new Date(strArray[3] * 10);
        const row = table.insertRow();
        const cell1 = row.insertCell(0);
        const cell2 = row.insertCell(1);
        const cell3 = row.insertCell(2);
        const cell4 = row.insertCell(3);
        const cell5 = row.insertCell(4);
        cell1.innerHTML = strArray[0];
        cell2.innerHTML = strArray[1];
        cell3.innerHTML = strArray[2];
        cell4.innerHTML = strArray[3];
        cell5.style.width = '60%';
        cell5.innerHTML = timestamp;
        var no = i+1;
      }
      console.log(no);
      if (isNaN(no)){
        var no = 1;
      } else {
        var no = no+1;
      }
      const last_no = no;
      console.log(last_no);
      $("#next_no").val(last_no);
    }

    $(function() {
      showList();
    });


</script>