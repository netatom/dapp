 <!-- Datatable style -->
<link rel="stylesheet" href="<?= base_url() ?>public/plugins/datatables/dataTables.bootstrap.css">  

<div class="datalist">
    <table id="example1" class="table table-bordered table-hover">
        <thead>
            <tr>
                <th width="50">No</th>
                <th>User ID</th>
                <th>User Name</th>
                <th>Email</th>
                <th>Wallet Address</th>
                <th>Remit</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($info as $row): ?>
            <tr>
            	<td>
					<?=$row['admin_id']?>
                </td>
                <td>
                <h4 class="m0 mb5"><?=$row['username']?></h4>
                </td> 
                <td>
					<?=$row['firstname']?> <?=$row['lastname']?>
                    (<small class="text-muted"><?=$row['admin_role_title']?></small>)
                </td>
                <td>
					<?=$row['email']?>
                </td>
                <td>
                    <?=$row['wallet_address']?>
                </td> 
                <td>
                    <?php 
                        if($row['wallet_address']) {
                    ?>
                        <a href="<?php echo site_url("admin/transaction?wallet_address=".$row['wallet_address']); ?>" class="btn btn-warning btn-xs mr5" >
                        <i class="fa fa-money"></i>
                        </a>
                    <?php
                        }
                    ?>
                    

                </td>
            </tr>
            <?php endforeach;?>
        </tbody>
    </table>
</div>


<!-- DataTables -->
<script src="<?= base_url() ?>public/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?= base_url() ?>public/plugins/datatables/dataTables.bootstrap.min.js"></script>
<script>
  $(function () {
    $("#example1").DataTable();
  });
</script> 
