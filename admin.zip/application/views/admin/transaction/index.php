<?php

// print_r($get_user_detail);
// foreach($get_user_detail as $user_detail):
// echo $user_detail;
// endforeach

if(isset($_GET['wallet_address'])) {
  $wallet_address = $_GET['wallet_address'];
  //echo $partner_id;
} else {
  $wallet_address ="";
}
 ?>
 
 <section class="content">
   <div class="box">
    <div class="box-header">
      <h3 class="box-title">Remittance</h3>
    </div>
    <!-- /.box-header -->
    <div class="box-body table-responsive">
      <table class="table table-bordered" width="100%" cellspacing="0">
                <thead>
                  <tr>
                    <th width="50%">My Account</th>
                    <th width="50%" colspan="3">Remittance Account</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td><input class="form-control" id="account" value="<?php echo $get_user_detail['wallet_address']; ?>" ></td>
                    <td colspan="3"><input class="form-control" id="receiver" value="<?php echo $wallet_address;?>" ></td>
                  </tr>
                </tbody>

                <thead>
                  <tr>
                    <th>Banance(Ether)</th>
                    <th colspan="3">Password/Action</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td><input id="amount" type="number" class="form-control"/></td>
                    <td><input id="pass" type="password" class="form-control"/></td>
                    <td>
                      <a class="btn btn-primary btn-block" id="send_btn">Send</a>
                    </td>
                    <td>
                      <a class="btn btn-primary btn-block" id="cancel_btn">Back</a>
                    </td>
                  </tr>
                </tbody>
                
            </table>
            <table>
              <div id="message"></div>
            </table>
    </div>
    <!-- /.box-body -->
  </div>
  <!-- /.box -->
</section>  

<script>
    $(document).ready(function(){
			$("#cancel_btn").click(function(){
                window.history.go(-1);
            });

			$("#send_btn").click(function(){

            var receiver = $( '#receiver' ).val();
            var amount = $( '#amount' ).val();
            var pass = $( '#pass' ).val();

            if (receiver == "") {
              alert("Partner Account를 입력해주세요.")
            } else if (amount == ""){
              alert("Banance를 입력해주세요.")
            } else if (pass == ""){
              alert("Password를 입력해주세요.")
            } else {

              const address = document.getElementById('account').value;
              const toAddress = receiver;
              const amount = web3.toWei(document.getElementById('amount').value, 'ether');
              const amount_original = document.getElementById('amount').value;

                if (web3.personal.unlockAccount(address, pass)) 
                {
                  web3.eth.sendTransaction(
                    { from: address, to: toAddress, value: amount },
                    (err, result) => {
                      if (!err) {
                        document.getElementById('message').innerText = ' ';
                        const idiv = document.createElement('div');
                        document.getElementById('message').appendChild(idiv);
                        let input = `
                            Transaction Result: ${result}<br/>
                            <a href="history?id=<?php echo $get_user_detail['wallet_address']; ?>&partner_id=<?php echo $wallet_address;?>&amount=${amount_original}">
                            (click to write a transaction history)
                            </a>
                        `;
                        idiv.innerHTML = input;
                        console.log(`Transaction is sent Successful! ${result} `);
                      } else console.log(err);
                    }
                  );
                }
              
            }

            });

    });
</script>  